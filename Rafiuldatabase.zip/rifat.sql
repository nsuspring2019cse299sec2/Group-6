--
-- Database: `rifat`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookinfo`
--

CREATE TABLE `bookinfo` (
  `bookname` varchar(225) NOT NULL,
  `bookdetails` varchar(225) NOT NULL,
  `bookpic` blob,
  `author` varchar(50) NOT NULL,
  `publisher` varchar(225) NOT NULL,
  `edition` varchar(225) NOT NULL,
  `isbn` varchar(225) NOT NULL,
  `price` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `dealid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookinfo`
--

INSERT INTO `bookinfo` (`bookname`, `bookdetails`, `bookpic`, `author`, `publisher`, `edition`, `isbn`, `price`, `catid`, `dealid`) VALUES
('Harry Potter', 'Fantasy', 0x446561642e6a7067, 'J.K Rawling', 'North Publishers ', '7th', 'J', 9, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `catid` int(11) NOT NULL,
  `name` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`catid`, `name`) VALUES
(2, 'Norwegian Wood');

-- --------------------------------------------------------

--
-- Table structure for table `deal`
--

CREATE TABLE `deal` (
  `dealid` int(11) NOT NULL,
  `bookname` varchar(50) NOT NULL,
  `dealtype` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deal`
--

INSERT INTO `deal` (`dealid`, `bookname`, `dealtype`) VALUES
(1, 'The Prisoner of Azkaban', 'Buy');

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE `userinfo` (
  `username` varchar(225) NOT NULL,
  `email` varchar(40) NOT NULL,
  `location` varchar(225) NOT NULL,
  `contactnumber` varchar(14) NOT NULL,
  `password` varchar(50) NOT NULL,
  `confirmpassword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`username`, `email`, `location`, `contactnumber`, `password`, `confirmpassword`) VALUES
('Rifat', 'raifat@gmail.com', 'dhaka', '01740588909', '202cb962ac59075b964b07152d234b70', ''),
('rafiul', 'gmail', 'ban', '00000', '123', '123'),
('raifulalam', 'raif@gmail.com', 'dhakak', '9099', '202cb962ac59075b964b07152d234b70', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`catid`);

--
-- Indexes for table `deal`
--
ALTER TABLE `deal`
  ADD PRIMARY KEY (`dealid`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
